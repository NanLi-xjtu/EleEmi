/***************************************************************************
quantum emission---Quantum model of space-charge-limited field emission in a nanogap
***************************************************************************/
#include "qe.h"

QE *qe, *qclOld;
DFT dft;
xc_func_type func_X, func_C;
int func_X_id, func_C_id;
int Nqe;
int Ncore; //the number of threads
int optionQE = 0; //include quantum emission(phixc and phisc)(1); opposite(0).
int optionPhixc = 1; //include phixc(1); not include phixc(0);
int approximateQE; //the result is real(0) or approximate(1)
real dqe, qe_omega;
real uQ, uLastPoint = 0.;
real phixcAvgQE, phixAvgQE, phicAvgQE, phiAvgQE, qAvg, nAvg, nAvg__m3;
int printQE;

//boundary
real phi0, phi1, q1, q1_;

real QuantumEmission (real Vg, real D, real T, int optionPrint, real omega, real CONV) //--V, nm, K;
{
	int n, i, step;
	real u, uNew, F, phig, lambda0, lambda, a0, n0, EH, Jemi, JCL, uDiff, diffQCL, uOld, qDiff, phiDiff, phixcDiff, q2Avg, phi2Avg, phixc2Avg;
	real start1, end1, time1, start2, end2, time2, time;
	QE *qeOld;

/*********************************init************************************/
	a0 = (4. * M_PI * epsilon0 * Sqr(planck_)) / (eleMass * Sqr(eleChar)); //--m
	EH = Sqr(eleChar) / (4. * M_PI *epsilon0 * a0); //--J
	EH /= eleChar; //--eV
	lambda0 = sqrt(Sqr(planck_) / (2. * eleChar * eleMass * Vg)); //--m
	lambda0 *= 1.e9; //--nm
	lambda = D / lambda0; //--dimensionless
	phig = Vg / EH; //--dimensionless
	n0 = (2. * epsilon0 * Vg) / (3. * eleChar * Sqr(D * 1.e-9)); //--m-3
	F = Vg / D; //--V/nm
	printf ("a0 = %f A\n", a0 * 1.e10);
	printf ("the electron de Broglie wavelength at %.2f V : %.4e nm, n0 = %.4e m-3\n", Vg, lambda0, n0);
	printf ("Vg = %.4e V, lambda = %.4e, phig = %.4e\n", Vg, lambda, phig);

	QCLInit (lambda, Nqe);
	AllocMem (qeOld, Nqe, QE);
/**********************electron emission equation**************************/
	optionQE = 0;
	Jemi = ObtainEmissionCurrent (D, F, T, 0, 0, 0); //--A/nm2
	JCL = CalJCL (Vg, D); //--A/nm2
	u = Jemi / JCL;
	printf ("u = %.4e\n", u);
/*********************time-independent Schrodinger*************************/
/***************************Poisson equation*******************************/
/**********************density functional theory***************************/
/***********************electron emission equation*************************/
	optionQE = 1;
	step = 0;
	time1 = 0.;
	time2 = 0.;
	if (fabs(uLastPoint) > 1.e-100 && fabs (uLastPoint / u) > 1.e-2 \
	    && fabs (uLastPoint / u) < 1.e2) {
		u = uLastPoint;
	}
	if (u > 1.) u = 1.;
	printf ("u = %.4e\n", u);
	while (1)
	{
		step ++;
		uDiff = diffQCL = qDiff = phiDiff = phixcDiff = 0.;
		//QCL function
		start1 = omp_get_wtime ();
		DO_QE {
			qeOld[n] = qe[n];
		}
		if (CalQCLFunction (u, lambda, phig, Vg, D, 1.e-13 * Sqr(u))) {
			printf ("\nwarning: (qe.c - QuantumEmission()): time-independet Schrodinger and Poisson equations do not converge\n");
			printf ("the emission current 'u = %.4e' maybe over the maximum\n", u);
//			PrintQE (F, D);
//			exit (1);
			u *= 0.9;
			FreeQE ();
			QCLInit (lambda, Nqe);
			continue;
		}
		DO_QE {
			phiDiff += Sqr(qe[n].phi - qeOld[n].phi);
			phixcDiff += Sqr(qe[n].phixc - qeOld[n].phixc);
		}
		diffQCL = phiDiff + phixcDiff;
		end1 = omp_get_wtime ();
		time1 += end1 - start1;
		//current emission function
		start2 = omp_get_wtime ();
		uOld = u;
		Jemi = ObtainEmissionCurrent (D, F, T, 0, 0, 0); //--A/nm2
		uNew = Jemi / JCL;
		uDiff += Sqr(uNew - u);
		u = (1. - omega) * u + omega * uNew;
		end2 = omp_get_wtime ();
		time2 += end2 - start2;

		time = time1 + time2;

		phi2Avg = phixc2Avg = 0.;
		DO_QE {
			phi2Avg += Sqr(qe[n].phi) / Nqe;
			phixc2Avg += Sqr(qe[n].phixc) / Nqe;
		}
		if ((int)time / 60 >= 30) {
			printf ("beyond the upper limit of convergence time( > 30 minutes)\n");
		}
		if (step >= 20) omega /= 2.;
		if (step % 1 == 0) {
			if (step == 1) printf ("u          uDiff      phiDiff    phixcDiff  totdiff/u2 \n");
			printf ("%.4e %.4e %.4e %.4e %.4e\n", u, uDiff, phiDiff, phixcDiff, (uDiff + diffQCL) / Sqr(u));
		}
		if ((uDiff + diffQCL) / Sqr(u) < CONV) {
			approximateQE = 0;
			uLastPoint = u;
			break;
		}
		if (diffQCL / Sqr(u) < 1.e-12 && step >= 100) {
			approximateQE = 1;
			uLastPoint = u;
			break;
		}
	}

	phixcAvgQE = phixAvgQE = phicAvgQE = phiAvgQE = qAvg = nAvg = 0.;
	for (i = 0; i < Nqe; i ++) {
		phixcAvgQE += qe[i].phixc / Nqe;
		phixAvgQE += qe[i].phix / Nqe;
		phicAvgQE += qe[i].phic / Nqe;
		phiAvgQE += qe[i].phi / Nqe;
		qAvg += qe[i].q / Nqe;
		nAvg += Sqr(qe[i].q) / Nqe;
	}
	ObtainEmissionCurrent (D, F, T, 0, 0, 1); //print emission parameters including potential barrier and transmition parameters
	if (optionPrint == 1) PrintQE (F, D);
	FreeQE ();
	free (qeOld);

	return (u);
}

void QCLInit (real lambda, int N)
{
	int n;

	//parameters
	uQ = 0;

	//allocte memory
	AllocMem (qe, N, QE);
	AllocMem (qclOld, N, QE);
	AllocMem (dft.rho, N, real);
	AllocMem (dft.x, N, real);
	AllocMem (dft.sigma, N, real);
	AllocMem (dft.deltaRho, N, real);
	AllocMem (dft.exc, N, real);
	AllocMem (dft.ex, N, real);
	AllocMem (dft.ec, N, real);
	AllocMem (dft.Vxc, N, real);
	AllocMem (dft.Vx, N, real);
	AllocMem (dft.Vc, N, real);
	AllocMem (dft.VxRho, N, real);
	AllocMem (dft.VcRho, N, real);
	AllocMem (dft.VxSigma, N, real);
	AllocMem (dft.VcSigma, N, real);
	AllocMem (dft.gVxSigma, N, real);
	AllocMem (dft.gVcSigma, N, real);
	AllocMem (dft.lapl, N, real);
	AllocMem (dft.tau, N, real);
	AllocMem (dft.VxLapl, N, real);
	AllocMem (dft.VcLapl, N, real);
	AllocMem (dft.VxTau, N, real);
	AllocMem (dft.VcTau, N, real);

	dqe = 1. / (N - 1.);
	DO_QE {
		qe[n].q = 0.;
		qe[n].phi = 0.;
		qe[n].phixc = 0.;
		qe[n].phix = 0.;
		qe[n].phic = 0.;
		qe[n].rs = 0.;
		qe[n].q2 = 0.;
		qe[n].theta = 0.;
		qe[n].x = n * dqe;
	}
	DO_QE {
		dft.rho[n] = 0.;
		dft.x[n] = 0.;
		dft.sigma[n] = 0.;
		dft.deltaRho[n] = 0.;
		dft.exc[n] = 0.;
		dft.ex[n] = 0.;
		dft.ec[n] = 0.;
		dft.Vxc[n] = 0.;
		dft.Vx[n] = 0.;
		dft.Vc[n] = 0.;
		dft.VxRho[n] = 0.;
		dft.VcRho[n] = 0.;
		dft.VxSigma[n] = 0.;
		dft.VcSigma[n] = 0.;
		dft.gVxSigma[n] = 0.;
		dft.gVcSigma[n] = 0.;
		dft.lapl[n] = 0.;
		dft.tau[n] = 0.;
		dft.VxLapl[n] = 0.;
		dft.VcLapl[n] = 0.;
		dft.VxTau[n] = 0.;
		dft.VcTau[n] = 0.;
	}
}

/**********************Density Functional Theory***************************/
void DFTCalculation (QE *qe, real lambda, real phig, real Vg_V, real D_nm)
{
	int n, n1, n2;
	real rs, epsilonx, k, epsilonc, depsilonx_drs, depsilonc_drs, q, n0, a0;
	real d, c, A, a1, b1, b2, b3, b4;
	real vx;

	//calculate rho, x, sigma
	a0 = (4. * M_PI * epsilon0 * Sqr(planck_)) / (eleMass * Sqr(eleChar)); //--m
	n0 = (2. * epsilon0 * Vg_V) / (3. * eleChar * Sqr(D_nm * 1.e-9)); //--m-3
	DO_QE {
		dft.rho[n] = n0 * Sqr(qe[n].q) * Cube(a0); //--dimensionless for DFT
		dft.x[n] = qe[n].x * D_nm / (a0 * 1.e9); //--dimensionless for DFT
	}
	DO_QE {
		n1 = n + 1;
		n2 = n - 1;
		if (n == Nqe - 1) n1 = n;
		if (n == 0) n2 = n;

		dft.deltaRho[n] = (dft.rho[n1] - dft.rho[n2]) / (dft.x[n1] - dft.x[n2]);
		dft.sigma[n] = Sqr (dft.deltaRho[n]);
	}

	DO_QE {
		n1 = n + 1;
		n2 = n - 1;
		if (n == Nqe - 1) n1 = n;
		if (n == 0) n2 = n;

		dft.lapl[n] = (dft.deltaRho[n1] - dft.deltaRho[n2]) / (dft.x[n1] - dft.x[n2]);
		dft.tau[n] = 3./10. * pow (3. * Sqr (M_PI), 2./3.) * pow (dft.rho[n], 5./3.);
	}
	
	//exchange
	switch(func_X.info->family)
	{
		case XC_FAMILY_LDA:
			xc_lda_exc_vxc (&func_X, Nqe, dft.rho, dft.ex, dft.VxRho);
			DO_QE dft.Vx[n] = dft.VxRho[n];
			break;
		case XC_FAMILY_GGA:
		case XC_FAMILY_HYB_GGA:
			xc_gga_exc_vxc (&func_X, Nqe, dft.rho, dft.sigma, dft.ex, dft.VxRho, dft.VxSigma);
			DO_QE dft.Vx[n] = dft.VxRho[n];
/*
			DO_QE {
				n1 = n + 1;
				n2 = n - 1;
				if (n == Nqe - 1) n1 = n;
				if (n == 0) n2 = n;
				
				dft.Vx[n] = dft.ex[n] + dft.rho[n] * dft.VxRho[n] - 2. 
				     * (dft.rho[n1] * dft.VxSigma[n1] * dft.deltaRho[n1] 
				        - dft.rho[n2] * dft.VxSigma[n2] * dft.deltaRho[n2]) 
				     / (dft.x[n1] - dft.x[n2]);
			}
*/
			
			break;
		case XC_FAMILY_MGGA:
			xc_mgga_exc_vxc (&func_X, Nqe, dft.rho, dft.sigma, dft.lapl, dft.tau, dft.ex, dft.VxRho, dft.VxSigma, dft.VxLapl, dft.VxTau);
			DO_QE dft.Vx[n] = dft.VxRho[n];
/*
			DO_QE {
				n1 = n + 1;
				n2 = n - 1;
				if (n == Nqe - 1) n1 = n;
				if (n == 0) n2 = n;

				dft.Vx[n] = dft.ex[n] + dft.rho[n] * dft.VxRho[n] - 2. 
				   	  * (dft.rho[n1] * dft.VxSigma[n1] * dft.deltaRho[n1] 
				  	      - dft.rho[n2] * dft.VxSigma[n2] * dft.deltaRho[n2]) 
				 	    / (dft.x[n1] - dft.x[n2]) + dft.rho[n] * dft.VxTau[n]
					  * 1./2. * pow (3. * Sqr(M_PI), 2./3.) * pow (dft.rho[n], 2./3.);
			}
*/
			break;
		default:
			printf ("the family should be LDA, GGA, or MGGA");
			exit (1);
	}

	//correlation
	switch(func_C.info->family)
	{
		case XC_FAMILY_LDA:
			xc_lda_exc_vxc(&func_C, Nqe, dft.rho, dft.ec, dft.VcRho);
			DO_QE dft.Vc[n] = dft.VcRho[n];
			break;
		case XC_FAMILY_GGA:
		case XC_FAMILY_HYB_GGA:
			xc_gga_exc_vxc (&func_C, Nqe, dft.rho, dft.sigma, dft.ec, dft.VcRho, dft.VcSigma);
			DO_QE dft.Vc[n] = dft.VcRho[n];
/*
			DO_QE {
				n1 = n + 1;
				n2 = n - 1;
				if (n == Nqe - 1) n1 = n;
				if (n == 0) n2 = n;

				dft.Vc[n] = dft.ec[n] + dft.rho[n] * dft.VcRho[n] - 2. 
					     * (dft.rho[n1] * dft.VcSigma[n1] * dft.deltaRho[n1] 
					        - dft.rho[n2] * dft.VcSigma[n2] * dft.deltaRho[n2]) 
					     / (dft.x[n1] - dft.x[n2]);
			}
*/
			break;
		case XC_FAMILY_MGGA:
			xc_mgga_exc_vxc (&func_C, Nqe, dft.rho, dft.sigma, dft.lapl, dft.tau, dft.ec, dft.VcRho, dft.VcSigma, dft.VcLapl, dft.VcTau);
			DO_QE dft.Vc[n] = dft.VcRho[n];
/*
			DO_QE {
				n1 = n + 1;
				n2 = n - 1;
				if (n == Nqe - 1) n1 = n;
				if (n == 0) n2 = n;

				dft.Vc[n] = dft.ec[n] + dft.rho[n] * dft.VcRho[n] - 2. 
				   	  * (dft.rho[n1] * dft.VcSigma[n1] * dft.deltaRho[n1] 
				  	      - dft.rho[n2] * dft.VcSigma[n2] * dft.deltaRho[n2]) 
				 	    / (dft.x[n1] - dft.x[n2]) + dft.rho[n] * dft.VcTau[n]
					  * 1./2. * pow (3. * Sqr(M_PI), 2./3.) * pow (dft.rho[n], 2./3.);
			}
*/
			break;
		default:
			printf ("the family should be LDA, GGA, or MGGA");
			exit (1);
	}

	DO_QE {
		dft.exc[n] = dft.ex[n] + dft.ec[n];
		dft.Vxc[n] = dft.Vx[n] + dft.Vc[n];
		qe[n].phix = dft.Vx[n] / phig;
		qe[n].phic = dft.Vc[n] / phig;
		qe[n].phixc = qe[n].phix + qe[n].phic; //include 
	}
/*
	FILE *output;
	output = WriteFile ("DFT.dat");	
	fprintf (output, "x rho Vx Vc Vxc exc\n");
	DO_QE fprintf (output, "%e %e %e %e %e %e\n", dft.x[n], dft.rho[n], dft.Vx[n], dft.Vc[n], dft.Vxc[n], dft.exc[n]);
	fclose (output);
	exit (1);
*/
}

void BoundaryCondition_Koh (real ux)
{
	phi0 = 0.;
	phi1 = 0.;
	q1 = sqrt(2. * ux / 3.);
	q1_ = 0;

	qe[0].phi = phi0;
	qe[Nqe-1].phi = phi1;
	qe[Nqe-1].q = q1;
}

/*********************time-independent Schrodinger*************************/
/***************************Poisson equation*******************************/
void SingleQCLFunction (int i, real ux, real lambdax, real phigx)
{
	real rs, drs, phiNew, qNew, Vxc, omega1, omega2;

	omega1 = 1.8;
	omega2 = 1.;

	if (i == Nqe-1) phiNew = phi1;
	else if (i == 0) phiNew = phi0;
	else {
		phiNew = (qe[i+1].phi + qe[i-1].phi - (2. / 3.) * Sqr(qe[i].q) * Sqr(dqe)) / 2.;
//		phiNew = 0.;
	}
	qe[i].phi = (1. - omega1) * qe[i].phi + omega1 * phiNew;

	if (i == Nqe-1) {
		qNew = 0.5 * Sqr(lambdax) * (-qe[i].phi - qe[i].x + qe[i].phixc + (4. / 9.) * (Sqr(ux) / pow(qe[i].q, 4.))) \
			    * qe[i].q * Sqr(dqe) + qe[i].q - dqe * q1_; //boundary
		qe[i-1].q = (1. - omega2) * qe[i-1].q + omega2 * qNew;
	} else if (i != 0) {
		qNew = Sqr(lambdax) * (-qe[i].phi - qe[i].x + qe[i].phixc + (4. / 9.) * (Sqr(ux) / pow(qe[i].q, 4.))) \
		       * qe[i].q * Sqr(dqe) + 2. * qe[i].q - qe[i+1].q; //Koh
		qe[i-1].q = (1. - omega2) * qe[i-1].q + omega2 * qNew;
	}
}

/*********************time-independent Schrodinger*************************/
/***************************Poisson equation*******************************/
/**********************Density Functional Theory***************************/
int CalQCLFunction (real ux, real lambdax, real phigx, real Vg_V, real D_nm, real CONV)
{
	int i, n, steps, Nthreads, NthreadsMax, SPConvFlag;
	real totalDiff, qTotalDiff, phiTotalDiff, phixcTotalDiff, q2Avg, integral, a;

	//boundary condition
	BoundaryCondition_Koh (ux);

	//main loop
	NthreadsMax = omp_get_num_procs();
	SPConvFlag = 0;	
	steps = 1;;
	while (1)
	{
		if (steps % 1000 == 0) {
			DO_QE qclOld[n] = qe[n];
		}

		if (steps <= 100) Nthreads = 1;
		else if (NthreadsMax < Ncore) Nthreads = NthreadsMax;
		else Nthreads = Ncore;

		//QCL Calculation
		#pragma omp parallel for num_threads(Nthreads)
		for (i = Nqe-1; i >= 0; i --) SingleQCLFunction (i, ux, lambdax, phigx);

		if (steps % 1000 == 0) {
			if (qTotalDiff + phiTotalDiff < CONV * 10.) {
				if (optionPhixc == 1) {
					DFTCalculation (qe, lambdax, phigx, Vg_V, D_nm); //DFT functionals
				} else if (optionPhixc == 0) {
					DO_QE qe[n].phixc = qe[n].phix = qe[n].phic = 0.; //not include DFT
				}
				SPConvFlag = 1;
			} else {
				SPConvFlag = 0;
			}
		}
		

/********************************Convergence*******************************/
		if (steps % 10000 == 0) {
			totalDiff = qTotalDiff = phiTotalDiff = phixcTotalDiff = 0;
			DO_QE {
				qTotalDiff += Sqr (qe[n].q - qclOld[n].q);
				phiTotalDiff += Sqr (qe[n].phi - qclOld[n].phi);
				phixcTotalDiff += Sqr (qe[n].phixc - qclOld[n].phixc);
			}
			totalDiff = qTotalDiff + phiTotalDiff + phixcTotalDiff;

			q2Avg = 0.;
			DO_QE {
				q2Avg += Sqr(qe[n].q) / Nqe;
			}
			if ((int)(totalDiff * 1.e100) != 0 && isnormal(totalDiff) == 0) {
				uQ = ux;
				printf ("totalDiff = %e, qDiff = %e, phiDiff = %e, phixcDiff = %e\n", \
					totalDiff, qTotalDiff, phiTotalDiff, phixcTotalDiff);
				return (1);
			}
			if (totalDiff < CONV && SPConvFlag == 1) {
				DO_QE {
					qe[n].rs = pow(((3. * lambdax) / (2. * phigx * fabs(qe[n].q))), (2. / 3.));
					qe[n].q2 = Sqr(qe[n].q);
/*					//integral
					integral = 0.;
					if (n < Nqe - 1) {
						for (i = n; i < Nqe; i ++) {
							if (i == n || i == Nqe - 1) a = 1. / 2.;
							else a = 1.;
							integral += a / Sqr(qe[i].q);
						}
						integral *= dqe;
					}
					qe[n].theta = -2. / 3. * ux * sqrt(lambdax) * integral;
*/
				}
				return (0);
			}
//			if (steps == 10000) printf("steps totalDiff/u2 qDiff        phiDiff      phixcDiff\n");
//			printf("%5d %e %e %e %e\n", steps, totalDiff / Sqr(ux), qTotalDiff, phiTotalDiff, phixcTotalDiff);
		}
		if (steps > 1.e6) {
			printf ("warning: (qe.c - CalQCLFuntion ()), spend too long time to converge\n");
			return (0);
		}
		steps ++;
	}
}

void SingleQCL_Koh (real lambdax, real phigx, real Vg_V, real D_nm, real CONV)
{
	int n, i, nu;
	real ux, uMin, uMax, du;

	//init	
	for (i = 0; i < Nqe; i ++) {
		qe[i].phixc = 0.;
		qe[i].phi = 0.;
		qe[i].q = 0.;
	}

	uMin = 0.;
	uMax = 5.;
	du = 0.01;
	nu = (uMax - uMin) / du;
	for (n = 0; n <= nu; n ++){
		ux = pow(10., (uMin + du * n));

		//boundary condition
		BoundaryCondition_Koh (ux);

		if(CalQCLFunction (ux, lambdax, phigx, Vg_V, D_nm, CONV)) break;
	}
}

void CalJQCL_Koh (real CONV)
{
	int n, nVg;
	real D, Vgx, VgMin, VgMax, dVg, phigx, lambda0, lambdax, a0, EH;

	D = 1.; //--nm
	a0 = (4. * M_PI * epsilon0 * Sqr(planck_)) / (eleMass * Sqr(eleChar)); //--m
	EH = Sqr(eleChar) / (4. * M_PI *epsilon0 * a0); //--J
	EH /= eleChar; //--eV

	VgMin = 0.;
	VgMax = 2.;
	dVg = 0.01;
	nVg = (VgMax - VgMin) / dVg;
	printf("   Vg(V)      uQ\n");
	fprintf(QCL_file, "Vg(V) uQ\n");
	for (n = 0; n <= nVg; n ++) {
		Vgx = pow(10., (VgMin + dVg * n)); //--V

		lambda0 = sqrt(Sqr(planck_) / (2. * eleChar * eleMass * Vgx)); //--m
		lambda0 *= 1.e9; //--nm
		lambdax = D / lambda0;
		phigx = Vgx / EH;
		QCLInit (lambdax, Nqe);

		SingleQCL_Koh (lambdax, phigx, Vgx, D, CONV);

		printf("%.4e  %.2e\n", Vgx, uQ);
		fprintf(QCL_file, "%.4e  %.2e\n", Vgx, uQ);

		FreeQE ();
	}
}

void PrintQE (real F_V_nm, real D_nm)
{
	int n;

	DO_QE {
		fprintf (qe_file, "%e %e %e %e %e %e %e %e %e %e %e\n", \
			 F_V_nm, D_nm, qe[n].x, qe[n].q, qe[n].phi, qe[n].phixc, qe[n].phix, qe[n].phic, qe[n].rs, qe[n].q2, qe[n].theta);
	}
}

void FreeQE ()
{
	free (qe);
	free (qclOld);
	free (dft.rho);
	free (dft.x);
	free (dft.sigma);
	free (dft.deltaRho);
	free (dft.exc);
	free (dft.ex);
	free (dft.ec);
	free (dft.Vxc);
	free (dft.Vx);
	free (dft.Vc);
	free (dft.VxRho);
	free (dft.VcRho);
	free (dft.VxSigma);
	free (dft.gVcSigma);
	free (dft.gVxSigma);
	free (dft.VcSigma);
}
