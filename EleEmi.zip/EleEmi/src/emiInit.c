#include "emiInit.h"

int flagEmiInit = 1;

void EmissionInit ()
{
	int dx, dE;

	if (flagEmiInit == 1) SetParamsEmi ();

	flagEmiInit = 0;
}

void SetParamsEmi ()
{
/*
	//cathod
	PHIWF_eV = 2.48; //the work function of Cu(4.5 or 4.65) Ba(2.48)
	EF_eV = 2.317; //Ba(2.317)
	//anode
	PHIWF2_eV = 2.48;
	EF2_eV = 2.317;

	anode = 1; //metal-vacuum-metal(1) or metal-vacuum(0)
	optionTFA = 1; //image potential for TFA(1) or classcial image potential(0)
	optionPhixc = 1; //include phixc(1) or not(0)
*/
	
	//constant
	Q_Jm = (Sqr(eleChar)) / (16. * M_PI * epsilon0); //--J m
	Q_eVnm = Q_Jm / (eleChar * 1.e-9); //--eV nm 
	g1__eV1_2nm = 2. * sqrt(2. * eleMass) / planck_; //--J-1/2m-1
	g1__eV1_2nm *= sqrt(eleChar) * 1.e-9; //--(eV)-1/2(nm)-1
	g2__eV1_2nm = 2. * M_PI * sqrt(eleMass) / planck_; //--J-1/2m-1
	g2__eV1_2nm *= sqrt(eleChar) * 1.e-9; //--(eV)-1/2(nm)-1
	Zs_A_eV2nm2 = (eleChar * eleMass) / (2. * Sqr(M_PI) * Cube(planck_)); //--A(Jm)-2
	Zs_A_eV2nm2 *= Sqr(eleChar) * 1.e-18; //--A(eVnm)-2
	Zs_A_eV3_2nm = (eleChar * sqrt(2. * eleMass)) / Sqr(planck); //--A J-3/2 m-1
	Zs_A_eV3_2nm *= pow(eleChar, 3./2.) * 1.e-9; //--A (eV)-3/2 (nm)-1
}

void SetParamsQE ()
{
	/*
	Ncore = 16;
	Nqe = 300;
	qe_omega = 0.5;
	func_X_id = 1;
	func_C_id = 25;
	*/
}

void SetupJobQE ()
{
	LibxcInit (&func_X, func_X_id);
	LibxcInit (&func_C, func_C_id);
}

void EndJobQE ()
{
	xc_func_end(&func_X);
	xc_func_end(&func_C);
}