extern "C"{
#include "main.h"
}
using namespace std;

int time;
real start, end;

int main (int argc, char **argv)
{
	double T, D, F, Vg, u, JCL, J;
	FILE *input;
	char line[1024], filename[128];
	
      printf("\n");
      printf("                                \\\\--//          \n");
      printf("                              (|-@ @--|)\n");
      printf("                               \\ (_)  /      \n");
      printf("                                  -         \n");
      printf("+------------o00o-------------------------------+\n");
      printf("|                                               |\n");
      printf("|                    EleEmi                      |\n");
      printf("|        Written by Nan Li && Bing Xiao         |\n");
      printf("|                  2023-08-1                    |\n");
      printf("| ln906061119@stu.xjtu.edu.cn, Nan Li from XJTU |\n");
      printf("|  bingxiao84@xjtu.edu.cn, Bing Xiao from XJTU  |\n");
      printf("|                                               |\n");
      printf("+----------------------------------oOOo---------+\n");
      printf("\n");


	start = omp_get_wtime();
	CheckParallel ();
        system ("mkdir out");
	PrintOpen ();
	GetNameList (argc, argv);
	PrintNameList (stdout);
	PrintNameList (namelist_file);
	
	SetParamsQE ();
	SetupJobQE ();
	
	sprintf (filename, "./in/electric_field");
	input = ReadFile (filename);
	fgets (line, 1024, input);

	while (1) {
		if (fgets (line, 1024, input) == NULL) break;
		sscanf (line, "%lg %lg %lg", &F, &D, &T); //--V/nm; nm; K
		Vg = D * F; //--V
		if (qeflag == 1) {
			u = QuantumEmission (Vg, D, T, printQE, qe_omega, 1.e-4); //--dimensionless
			JCL = CalJCL (Vg, D); //--A/nm2
		        J = u * JCL; //--A/nm2
		} else if (qeflag == 0) {
			J = ObtainEmissionCurrent (D, F, T, 0, 0, 1); //--A/nm2
		}
	
		printf ("F(V/nm)      D(nm)        T(K)         J(A/nm2)\n%e %e %e %e\n", F, D, T, J);
		fprintf (Jemission_file, "%e %e %e %e\n", F, D, T, u * JCL);
		fprintf (Jqe_file, "%e %e %e %e %e %e %e %e %d\n", \
					 F, D, u, qAvg, phiAvgQE, phixcAvgQE, phixAvgQE, phicAvgQE, approximateQE);
	}
	
	EndJobQE ();
	end = omp_get_wtime();
	time = end - start;
	printf("\ntime taken = %d h %d min %d s\n", time/3600, (time%3600)/60, time%60);
	PrintClose ();
	fclose (input);	
}

void CheckParallel ()
{
	int coreNum = omp_get_num_procs();

	printf ("\n-- Check Parallel\n\n");
	printf ("Core Num is %d \n", coreNum);
	printf ("ID : ");
	#pragma omp parallel
	{	
		int K = omp_get_thread_num();
		printf("%d ", K);
	}
	printf (": I'm ready\n");
	printf ("\n------------------------------------------------------------\n\n");
}

void LibxcInit (xc_func_type *func, int func_id)
{
	int ii, vmajor, vminor, vmicro;

	xc_version(&vmajor, &vminor, &vmicro);
	printf ("Libxc version: %d.%d.%d\n", vmajor, vminor, vmicro);

	if(xc_func_init(func, func_id, XC_UNPOLARIZED) != 0){
		fprintf(stderr, "Functional '%d' not found\n", func_id);
		exit (1);
	}
	if (func->info->kind == XC_EXCHANGE) printf ("\n-- Libxc: exchange\n\n");
	else if (func->info->kind == XC_CORRELATION) printf ("\n-- Libxc: correlation\n\n");
	else {
		printf ("\nerror: this functional is not exchange or correlation\n\n");
		exit (1);
	}
	printf ("family: %d, id: %d\n", func->info->family, func->info->number);
	printf("The functional '%s' is ", func->info->name);
	switch (func->info->kind) {
		case (XC_EXCHANGE):
			printf("an exchange functional");
			break;
		case (XC_CORRELATION):
			printf("a correlation functional");
			break;
		case (XC_EXCHANGE_CORRELATION):
			printf("an exchange-correlation functional");
			break;
		case (XC_KINETIC):
			printf("a kinetic energy functional");
			break;
		default:
			printf("of unknown kind");
			break;
	}
	printf(", it belongs to the '");

	switch (func->info->family) {
		case (XC_FAMILY_LDA):
			printf("LDA");
			break;
		case (XC_FAMILY_GGA):
			printf("GGA");
			break;
		case (XC_FAMILY_HYB_GGA):
			printf("Hybrid GGA");
			break;
		case (XC_FAMILY_MGGA):
			printf("MGGA");
			break;
		case (XC_FAMILY_HYB_MGGA):
			printf("Hybrid MGGA");
			break;
		default:
			printf("unknown");
			break;
	}
	printf("' family and is defined in the reference(s):\n");

	for(ii = 0; func->info->refs[ii] != NULL; ii++){
		printf("[%d] %s\n", ii+1, func->info->refs[ii]->ref);
	}

	printf ("\n------------------------------------------------------------\n\n");
}
