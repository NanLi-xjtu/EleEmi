#include "emission.h"

//get information from 'md' and 'electric' module
SurfaceAtoms *sat;
int satCount;
SurfaceGrids *sgr;
int sgrCount;

/*****************************patameters***********************************/
Emission *emi;
Transmission *tra;
real PHIWF_eV, phiWF, EF_eV; //cathod
real PHIWF2_eV, EF2_eV; //anode
real JCL_A_nm2, JEMI_A_nm2, JFN_A_nm2, JQCL_JCL;
int nEmi; //the number of points for X_nm
int nTra; //the number of points for E_eV
real xRangeMax, xRangeMin; //dimensionless
real eRangeMax, eRangeMin; //dimensionless
real Nottingham_W_nm2; //--W/nm2
int anode; //metal-vacuum-metal(1) or metal-vacuum(0)
int optionTFA; //image potential for TFA
int optionMetal; //the same metal (1) or different metals (2) for anode and cathod
real UAvg, phiWFAvg, phiaAvg, phiicAvg, phiscAvg, phixcAvg;
real UAvg_eV, phiWFAvg_eV, phiaAvg_eV, phiicAvg_eV, phiscAvg_eV, phixcAvg_eV;
int qeflag = 0;

//constant
real Q_Jm, Q_eVnm;
real Zs_A_eV2nm2, Zs_A_eV3_2nm;
real g1__eV1_2nm, g2__eV1_2nm; //--(eV)-1/2(nm)-1

int stepEmiTest = 1;

real ObtainEmissionCurrent (real GAP_nm, real F_V_nm, real T_K, real R_nm, real gamma, int optionPrint)
{
	int n;
	real J_A_nm2, dx, dE, VG_V;

	//get emission parameters
	SetParamsEmi ();

	//parameters
	VG_V = GAP_nm * F_V_nm;
	phiWF = PHIWF_eV / VG_V; //--dimensionless

/************************Obtain xRange and eRange**************************/
	nEmi = NPOINTS;
	nTra = NPOINTS;
	AllocMemEmi ();
	if (anode == 1 && optionTFA == 1) {
		xRangeMin = 0.;
		xRangeMax = 1.;
	} else if (anode == 1 && optionTFA == 0) {
		xRangeMin = 0.0001;
		xRangeMax = 0.9999;
	}
	else if (anode == 0){
		xRangeMin = 0.0001 / GAP_nm;
		xRangeMax = 20 / GAP_nm;
//		if (R_nm != 0) xRangeMax *= 10. / R_nm;
//		if (gamma > 10) xRangeMax *= gamma / 10.;
		if (F_V_nm < 10.) xRangeMax /= F_V_nm;
	}
	dx = (xRangeMax - xRangeMin) / (nEmi - 1);
	DO_EMI emi[n].x = n * dx + xRangeMin;
	CalBarPoten (F_V_nm, VG_V, GAP_nm, R_nm, gamma, dx);
	ObtainERange (F_V_nm, T_K, VG_V, GAP_nm, dx);
	ObtainXRange ();
	if (optionPrint == 1) PrintPotenTotal (F_V_nm, GAP_nm);

/****************Calculate Emission Current & Nottingham Heat**************/
	dx = (xRangeMax - xRangeMin) / (nEmi - 1);
	DO_EMI emi[n].x = n * dx + xRangeMin;
	CalBarPoten (F_V_nm, VG_V, GAP_nm, R_nm, gamma, dx);
	dE = (eRangeMax - eRangeMin) / (nTra - 1);
	DO_TRA tra[n].E = n * dE + eRangeMin;
	J_A_nm2 = CalJemi (F_V_nm, T_K, dE, dx, VG_V, GAP_nm);
	Nottingham_W_nm2 = CalPN (F_V_nm, T_K, dE, VG_V, GAP_nm);

	if (optionPrint == 1) {
		PrintTra (F_V_nm, GAP_nm);
		PrintPoten (F_V_nm, GAP_nm);

		//calculate average potential
		phiWFAvg = PHIWF_eV / VG_V;
		UAvg = phiaAvg = phiicAvg = phiscAvg = phixcAvg = 0.;
		DO_EMI {
			UAvg += emi[n].barrier / nEmi;
			phiaAvg += emi[n].phia / nEmi;
			phiicAvg += emi[n].phiic / nEmi;
			phiscAvg += emi[n].phisc / nEmi;
			phixcAvg += emi[n].phixc / nEmi;
		}
		phiWFAvg_eV = phiWFAvg * VG_V;
		UAvg_eV = UAvg * VG_V;
		phiaAvg_eV = phiaAvg * VG_V;
		phiicAvg_eV = phiicAvg * VG_V;
		phiscAvg_eV = phiscAvg * VG_V;
		phixcAvg_eV = phixcAvg * VG_V;
//		fprintf (test_file, "x(nm) U(eV) Va(eV) Vic(eV) Vxc(eV) Vsc(eV)\n");
//		for (n = 0; n < nEmi; n ++) 
//			fprintf (test_file, "%e %e %e %e %e %e\n", emi[n].x * GAP_nm, emi[n].barrier * VG_V, emi[n].phia * VG_V, \
				 emi[n].phiic * VG_V, emi[n].phixc * VG_V, emi[n].phisc * VG_V);
	}

	FreeEmi ();
	return (J_A_nm2); //--A/nm2
}

void CalBarPoten (real F_V_nm, real VG_V, real GAP_nm, real R_nm, real gamma, real dx)
{
	int n, i, nMin, nMax;
	real der, derMin;

	CalAppPoten (F_V_nm, VG_V, GAP_nm, R_nm, gamma);
	CalImaPoten (VG_V, GAP_nm, R_nm);
	CalXCPoten (F_V_nm, GAP_nm);
	CalSCPoten (F_V_nm, GAP_nm);

	#pragma omp parallel for
	DO_EMI {
		if (optionQE == 0) emi[n].barrier = phiWF + emi[n].phia + emi[n].phiic;
		else if (optionQE == 1) emi[n].barrier = phiWF + emi[n].phia + emi[n].phiic + emi[n].phixc - emi[n].phisc;
	}

	//check
	nMin = 0;
	nMax = 0;
	if (R_nm > 0.000001) {
		for (n = 1; n < nEmi; n ++) { //barrier rise, then reduce, then rise again
			if (emi[n].barrier < emi[n-1].barrier && emi[n].barrier < emi[n+1].barrier) {
				nMin = n;
				for (i = nMin; i < nEmi; i ++) emi[i].barrier = emi[nMin].barrier;
				break;
			}
		}
		for (n = 1; n < nEmi; n ++) { //barrier rise always
			if (emi[n].barrier > emi[n-1].barrier && emi[n].barrier > emi[n+1].barrier) {
				nMax = n;
			}
		}
		if (nMax == 0) { //barrier rise always
			derMin = (emi[2].barrier - emi[0].barrier) / (2. * dx);
			for (n = 1; n < nEmi; n ++) { //find the minimum value of derivative
				der = (emi[n+1].barrier - emi[n-1].barrier) / (2. * dx);
				if (fabs(derMin) > fabs(der)) {
					derMin = der;
					nMax = n;
				}
			}
			for (i = nMax; i < nEmi; i ++) emi[i].barrier = emi[nMax].barrier;
		}
	}
}

void CalAppPoten (real F_V_nm, real VG_V, real GAP_nm, real R_nm, real gamma)
{
	int n;
	real PHIA_eV, X_nm;

	#pragma omp parallel for private (X_nm, PHIA_eV)
	DO_EMI {
		X_nm = emi[n].x * GAP_nm;
		if (R_nm < 1.e-8) PHIA_eV = - F_V_nm * X_nm;
		else {
			PHIA_eV = - F_V_nm * (R_nm * (gamma - 1.) * X_nm + Sqr(X_nm)) \
				  / (gamma * X_nm + R_nm * (gamma - 1.)); //--eV
		}
		emi[n].phia = PHIA_eV / VG_V; //dimensionless
	}
}

void CalImaPoten (real VG_V, real GAP_nm, real R_nm)
{
	int n, i;
	real PHIIC_eV, X_nm, lambda, term, series;

	if (anode == 0 && optionTFA == 0) { //classical metal-vacuum system
		#pragma omp parallel for private (X_nm, PHIIC_eV)
		DO_EMI {
			X_nm = emi[n].x * GAP_nm;
			if (R_nm < 1.e-8) PHIIC_eV = - Q_eVnm / X_nm; //--eV
			else PHIIC_eV = - Q_eVnm / (X_nm * (1. + X_nm / (2. * R_nm)));
			emi[n].phiic = PHIIC_eV / VG_V; //dimensionless
		}
	} else if (anode == 1 && optionTFA == 0) { //calssical metal-vacuum-metal system
		DO_EMI {
			X_nm = emi[n].x * GAP_nm;
/*
			//a good approxomation by using the method followed.
			lambda = Sqr(eleChar) * log(2.) / (16. * M_PI * epsilon0 * GAP_nm * 1.e-9); //--J
			PHIIC_eV = - 1.15 * lambda * Sqr(GAP_nm) / (X_nm * (GAP_nm - X_nm)); //--J
			PHIIC_eV /= eleChar; //--eV
*/
			//image force method, within the framework of a local (classic) electrostatics
			term = 1. / (2. * X_nm); //--nm-1
			i = 1;
			while (1)
			{
				series = i * GAP_nm / (Sqr(i * GAP_nm) - Sqr(X_nm)) - 1. / (i * GAP_nm); //--nm-1
				term += series;
				if (series < 1.e-8) break;
				i ++;
			}
			term *= 1.e9; //--m-1
			term *= - Sqr(eleChar) / (8. * M_PI * epsilon0); //--J
			PHIIC_eV = term / eleChar; //--eV

			emi[n].phiic = PHIIC_eV / VG_V; //dimensionless
		}
	} else if (anode == 1 && optionTFA == 1 && GAP_nm < 50) { //metal-vacuum-metal system for TFA
		#pragma omp parallel for private (X_nm, PHIIC_eV)
		DO_EMI {
			X_nm = emi[n].x * GAP_nm;

			PHIIC_eV = ImagePotentialTFA (X_nm * 10., GAP_nm * 10.); //--A, A; --eV

			//check
			if (isfinite(PHIIC_eV) == 0) {
				printf ("\nerror (emission.c - CalImaPoten()): image potential is finite\n");
				exit (1);
			}
			emi[n].phiic = PHIIC_eV / VG_V; //dimensionless
		}
/*		
		FILE *output;
		output = WriteFile ("out/phi_ic.dat");
		DO_EMI fprintf (output, "%e %e\n", emi[n].x * GAP_nm, emi[n].phiic * VG_V);
		fclose (output);
		exit (2);
*/
	}else if (anode == 1 && optionTFA == 1 && GAP_nm > 50) { // k/(x+x0) for large gap
		DO_EMI {
			X_nm = emi[n].x * GAP_nm;
			PHIIC_eV = ImagePotentialx0 (X_nm * 10.) + ImagePotentialx0 ((GAP_nm - X_nm) * 10.); //--A; --eV
			emi[n].phiic = PHIIC_eV / VG_V; //dimensionless
		}
/*		
		FILE *output;
		output = WriteFile ("out/phi_ic.dat");
		DO_EMI fprintf (output, "%e %e\n", emi[n].x * GAP_nm, emi[n].phiic * VG_V);
		fclose (output);
		exit (2);
*/		
	}
}

void CalXCPoten (real F_V_nm, real GAP_nm)
{
	int n, i, Npoint;
	real *x, *y, *y2, y_, y__, y1_, yn_, phixcNew;

	if (optionQE == 1) {
		//find the nearest points for interpolation
		Npoint = 0;
		DO_QE {
			if (qe[n].x > (xRangeMin - dqe) && qe[n].x < (xRangeMax + dqe)) Npoint ++;
		}
		//check
		if (Npoint < 10) {
			printf ("error (emission.c - CalXCPoten()): the number of points used for interpolation is too small \
				\nNqe = %d (%d is used)may be too small\n", Nqe, Npoint);
			PrintPoten (F_V_nm, GAP_nm);
			exit (1);
		}
		x = vector (1, Npoint);
		y = vector (1, Npoint);
		y2 = vector (1, Npoint);
		i = 1;
		DO_QE {
			if (qe[n].x > (xRangeMin - dqe) && qe[n].x < (xRangeMax + dqe)) {
				x[i] = qe[n].x;
				y[i] = qe[n].phixc;
				i ++;
			}
		}
		y1_ = (y[2] - y[1]) / (x[2] - x[1]);
		yn_ = (y[Npoint] - y[Npoint-1]) / (x[Npoint] - x[Npoint-1]);
		Spline(x, y, Npoint, y1_, yn_, y2);
		DO_EMI {
			Splint(x, y, y2, Npoint, emi[n].x, &phixcNew);
			emi[n].phixc = phixcNew;
		}
/*
		x = vector (1, Nqe);
		y = vector (1, Nqe);
		y2 = vector (1, Nqe);
		y1_ = (qe[1].phixc - qe[0].phixc) / (qe[1].x - qe[0].x);
		yn_ = (qe[Nqe-1].phixc - qe[Nqe-2].phixc) / (qe[Nqe-1].x - qe[Nqe-2].x);
		DO_QE {
			x[n+1] = qe[n].x;
			y[n+1] = qe[n].phixc;
		}
		Spline(x, y, Nqe, y1_, yn_, y2);
		DO_EMI {
			Splint(x, y, y2, Nqe, emi[n].x, &phixcNew);
			emi[n].phixc = phixcNew;
		}
*/
		//check
		DO_EMI {
			if ((int)(emi[n].phixc * 1.e100) != 0 && isnormal(emi[n].phixc) == 0) {
				printf ("\nerror (emission.c - CalXCPoten()): exchange-correlation potential interpolation was wrong\n");
				PrintPoten (F_V_nm, GAP_nm);
				exit (1);
			}
		
		}
		free_vector(y2, 1 ,Nqe);
		free_vector(x, 1 ,Nqe);
		free_vector(y, 1 ,Nqe);
/*
		DO_EMI {
			//check
			if (emi[n].x - x[n] > 1.e-8) {
				printf ("\nthe x of Emi is different frome that of QCL\n");
				exit (1);
			}

			emi[n].phixc = phixc[n];
		}
*/
	} else if (optionQE == 0) {
		DO_EMI emi[n].phixc = 0.;
	}

}

void CalSCPoten (real F_V_nm, real GAP_nm)
{
	int n, i, Npoint;
	real *x, *y, *y2, y_, y__, y1_, yn_, phiNew;

	if (optionQE == 1) {
		//find the nearest points for interpolation
		Npoint = 0;
		DO_QE {
			if (qe[n].x > (xRangeMin - dqe) && qe[n].x < (xRangeMax + dqe)) Npoint ++;
		}
		//check
		if (Npoint < 10) {
			printf ("error (emission.c - CalSCPoten()): the number of points used for interpolation is too small \
				\nNqe = %d may be too small\n", Nqe);
			PrintPoten (F_V_nm, GAP_nm);
			exit (1);
		}
		x = vector (1, Npoint);
		y = vector (1, Npoint);
		y2 = vector (1, Npoint);
		i = 1;
		DO_QE {
			if (qe[n].x > (xRangeMin - dqe) && qe[n].x < (xRangeMax + dqe)) {
				x[i] = qe[n].x;
				y[i] = qe[n].phi;
				i ++;
			}
		}
		y1_ = (y[2] - y[1]) / (x[2] - x[1]);
		yn_ = (y[Npoint] - y[Npoint-1]) / (x[Npoint] - x[Npoint-1]);
		Spline(x, y, Npoint, y1_, yn_, y2);
		DO_EMI {
			Splint(x, y, y2, Npoint, emi[n].x, &phiNew);
			emi[n].phisc = phiNew;
		}
/*
		x = vector (1, Nqe);
		y = vector (1, Nqe);
		y2 = vector (1, Nqe);
		y1_ = (qe[1].phi - qe[0].phi) / (qe[1].x - qe[0].x);
		yn_ = (qe[Nqe-1].phi - qe[Nqe-2].phi) / (qe[Nqe-1].x - qe[Nqe-2].x);
		DO_QE {
			x[n+1] = qe[n].x;
			y[n+1] = qe[n].phi;
		}
		Spline(x, y, Nqe, y1_, yn_, y2);
		DO_EMI {
			Splint(x, y, y2, Nqe, emi[n].x, &phiNew);
			emi[n].phisc = phiNew;
		}
*/
		//check
		DO_EMI {
			if ((int)(emi[n].phisc * 1.e100) != 0 && isnormal(emi[n].phisc) == 0) {
				printf ("\nerror (emission.c - CalSCPoten()): space charge potential interpolation was wrong %e\n", emi[n].phisc);
				PrintPoten (F_V_nm, GAP_nm);
				exit (1);
			}
		}
		free_vector(y2, 1 ,Nqe);
		free_vector(x, 1 ,Nqe);
		free_vector(y, 1 ,Nqe);

/*
		DO_EMI {
			//check
			if (emi[n].x - x[n] > 1.e-8) {
				printf ("\nthe x of Emi is different frome that of QCL\n");
				exit (1);
			}

			emi[n].phisc = phi[n];
		}
*/
	} else if (optionQE == 0) {
		DO_EMI emi[n].phisc = 0.;
	}

}

void ObtainERange (real F_V_nm, real T_K, real VG_V, real GAP_nm, real dx)
{
	int n, i, n1, i1, i2, im, flag;
	real E, dE, Um, xm, xLeft, xRight, xTemp, x1, x2, sum, Um__, g1, g2, g3, integral, G, D, N, DN, DNmax, GUm_, dU; //--dimensionless
	real kT_eV, kT, E_kT;
	real arrayE[10000] = {0}, arrayDN[10000] = {0};

/*****************************find Um and G(Um)'***************************/
	im = 0;
	DO_EMI {
		if (emi[n].barrier > emi[im].barrier) {
			im = n;
		}
	}
	Um = emi[im].barrier;
	xm = emi[im].x;
	dU = fabs(Um * 0.01);
	GUm_ = - FunctionG ((Um - 2. * dU), F_V_nm, VG_V, GAP_nm, 0., dx) / (2. * dU);
/*
	if (im == 0) im ++;
	Um__ = (emi[im+1].barrier + emi[im-1].barrier - 2. * emi[im].barrier) / Sqr(dx);
	g2 = g2__eV1_2nm * sqrt(VG_V) * GAP_nm;
	GUm_ = - g2 / sqrt(fabs(Um__));
	printf ("GUm_ = %.e\n", GUm_);
*/
	eRangeMin = 0;
	eRangeMax = 0;
	flag = 1;
	E = 10. / VG_V;
	dE = E / 1000.;
	DNmax = 0.;
	n = 0;
	while (1) {
/******************************calculate D*N*******************************/
		G = FunctionG (E, F_V_nm, VG_V, GAP_nm, GUm_, dx);
		D = 1. / (1. + exp(G));
		N = FunctionN (E, T_K, VG_V);
		DN = D * N;
		arrayE[n] = E;
		arrayDN[n] = DN;
		
/******************************calculate ERange****************************/
		DNmax = Max (DN, DNmax);
		if (DN < DNmax / 1000.) {
			eRangeMin = E - dE;
			break;
		}
		E -= dE;
		n ++;

		//check
		if (n >= 10000) {
			printf ("error (emission.c - ObtainERange()): obtain E range calculation is wrong\n");
			PrintPoten (F_V_nm, GAP_nm);
			exit (1);
		}
	}
	for (i = 0; i < n+1; i ++) {
		if (arrayDN[i] > DNmax / 1000.) {
			eRangeMax = arrayE[i-1];
			break;
		}
	}
}

void ObtainXRange ()
{
	int n;

	for (n = 0; n < nEmi-1; n ++) {
		if (emi[n].barrier < eRangeMin && emi[n+1].barrier > eRangeMin) xRangeMin = emi[n].x;
		if (emi[n].barrier > eRangeMin && emi[n+1].barrier < eRangeMin) xRangeMax = emi[n+1].x;
	}
//	printf ("ERangemIN %f\n", eRangeMin);
}

real FunctionG (real E, real F_V_nm, real VG_V, real GAP_nm, real GUm_, real dx)
{
	int n, i, n1, i1, i2, im, flag;
	real Um, xm, xLeft, xRight, xTemp, x1, x2, sum, Um__, g1, g2, g3, integral, a, G; //--dimensionless
	real kT_eV, kT, E_kT;

/************************find Umax and xmax********************************/
	i = 0;
	DO_EMI {
		if (emi[n].barrier > emi[i].barrier) {
			i = n;
		}
	}
	Um = emi[i].barrier;
	xm = emi[i].x;

/*********************find x1 and x2 where U(x) = E************************/
	if (E < Um) {
		//x1
		xLeft = emi[0].x;
		xRight = xm;
		if (emi[0].barrier > E) {
			x1 = emi[0].x;
		}else {
			while (fabs(xRight - xLeft) > dx) {
				xTemp = (xRight + xLeft) / 2.;
				i = (xTemp - xRangeMin) / dx;//x -> i
				if (emi[i].barrier - E > 0) xRight =  xTemp;
					else xLeft = xTemp;
			}
			x1 = (xRight + xLeft) / 2.;
		}
		//x2
		xLeft = xm;
		xRight = emi[nEmi-1].x;
		if (emi[nEmi-1].barrier > E) {
			if (anode == 0) {
				printf("error(emission.c): Emin out of range(right), F = %.4f V/nm, barrierMin: %.4f, E: %.4f, eRange: [%.4f %.4f]\n", \
					F_V_nm, emi[nEmi-1].barrier, E, eRangeMin, eRangeMax);
				PrintPoten (F_V_nm, GAP_nm);
				PrintTra (F_V_nm, GAP_nm);
				ErrExit (ERR_POTENTIAL_BARRIER_INTEGRATION);
			} else if (anode == 1) {
				x2 = emi[nEmi-1].x;
			}
		}else {
			while (fabs(xRight - xLeft) > dx) {
				xTemp = (xRight + xLeft) / 2.;
				i = (xTemp - xRangeMin) / dx;//x -> i
				if (emi[i].barrier - E < 0) xRight =  xTemp;
				else xLeft = xTemp;
			}
				x2 = (xRight + xLeft) / 2.;
		}
	}else {
		x1 = xm;
		x2 = xm;
	}
/*****************************calculate G(E)*******************************/
	//dimensionless
	g1 = g1__eV1_2nm * sqrt(VG_V) * GAP_nm;
	g2 = g2__eV1_2nm * sqrt(VG_V) * GAP_nm;
//	g3 = 2. * GAP_nm * 1.e-9 / planck_ * sqrt(2. * eleChar * eleMass * VG_V); // g3 == g1
	//integral
	if (E < Um) {
		integral = 0;
		i1 = (x1 - xRangeMin) / dx;
		i2 = (x2 - xRangeMin) / dx;
		//this extended integral formula has the same order as Simpson's rule O(1/N4)
		integral = 0.;
		for (i = i1; i <= i2; i ++) {
			if (i == i1 || i == i2) a = 3. / 8.;
			else if (i == i1 + 1 || i == i2 - 1) a = 7. / 6.;
			else if (i == i1 + 2 || i == i2 - 2) a =  23. / 24.;
			else a = 1.;
			integral += a * sqrt(fabs(emi[i].barrier - E));
		}
		integral *= dx;
		G = g1 * integral;
	}else { //get G(E) from E and Um__
//		G = 0.; //when E = Um
		G = GUm_ * (E - Um); //when E near Um
	}

	return (G);
}

real FunctionN (real E, real T_K, real VG_V) //E--dimensionless; T_K--K
{
#if NDIM==3 //3D	
	real kT_eV, kT, E_kT, N;

	kT_eV = (kB * T_K) /eleChar; //--eV
	kT = kT_eV / VG_V;
	E_kT = - E / kT;
	if (E_kT < -30.) N = exp(E_kT);
	else if (E_kT >= -30. && E_kT <= 10.)	N = log(1. + exp(E_kT)); //--dimensionless
	else N = E_kT;
#elif NDIM==2 //2D
	int n, npx;
	real fx, px, fx0, px0, dpx, pxRangeMax, kT, E_kT, mkT, integral, N;

	E = E * VG_V * eleChar; //--J
	kT = kB * T_K; //--J
	E_kT = E / kT; //--dimensionless
	mkT = eleMass * kT; //--kg2 m2/s2
	px0 = 0.; //--kg m/s
	fx0 = 1. / (exp(Sqr(px0) / (2. * mkT) + E_kT) + 1.); //--dimensionless

	//find integral range
	n = 0;
	dpx = 1.e-25; //--kg m/s
	px = 0;
	while (1)
	{
		fx = 1. / (exp(Sqr(px) / (2. * mkT) + E_kT) + 1.); //--dimensionless
		px += dpx;
		n ++;

		if (fx / fx0 < 1.e-3) break;
	}
	pxRangeMax = px; //--kg m/s

	//integral
	npx = 1000;
	dpx = pxRangeMax / npx; //--kg m/s
	px = 0;
	integral = 0.;
	n = 0;
	while (1) {
		fx = 1. / (exp(Sqr(px) / (2. * mkT) + E_kT) + 1.); //--dimensionless
		integral += fx * dpx;
		px += dpx;
		n ++;

		if (n > npx) break;
	}
	N = (2. * planck_) / (eleMass * kT) * integral; //--m
	N *= 1.e9; //--nm
	
#endif
	return (N);
}

real CalJemi (real F_V_nm, real T_K, real dE, real dx, real VG_V, real GAP_nm)
{
	int n, im;
	real integral, a, E_kT, kT_eV, kT, dnMax, dnLeft, dnRight, Um, xm, dU, Um__, GUm_, g2;
	real g4; //--A/nm2J

/*****************************find Um and G(Um)'***************************/
	im = 0;
	DO_EMI {
		if (emi[n].barrier > emi[im].barrier) {
			im = n;
		}
	}
	Um = emi[im].barrier;
	xm = emi[im].x;
/*
	if (im == 0) im ++;
	Um__ = (emi[im+1].barrier + emi[im-1].barrier - 2. * emi[im].barrier) / Sqr(dx);
	g2 = g2__eV1_2nm * sqrt(VG_V) * GAP_nm;
	GUm_ = - g2 / sqrt(fabs(Um__)); 						//G(E) near Em
	printf ("GUm_ = %.e\n", GUm_);
*/
	dU = fabs(Um * 0.01);
	GUm_ = - FunctionG ((Um - 2. * dU), F_V_nm, VG_V, GAP_nm, 0., dx) / (2. * dU);	//linear extansion of G(E) above Em

	//integral
	integral = 0.;
	#pragma omp parallel for reduction(+:integral) private(a)
	DO_TRA {
		tra[n].g = FunctionG (tra[n].E, F_V_nm, VG_V, GAP_nm, GUm_, dx); //dimensionless
		tra[n].d = 1. / (1. + exp(tra[n].g)); //--dimensionless --WKBJ method
//		tra[n].d = 1. / (exp(tra[n].g)); //--dimensionless --WKB method
//		if (tra[n].E > Um) tra[n].d = 1.; //--dimensionless
		tra[n].n = FunctionN (tra[n].E, T_K, VG_V); //--dimensionless(3D); --nm(2D)
	
		//this extended integral formula has the same order as Simpson's rule O(1/N4)
		if (n == 0 || n == nTra - 1) a = 3. / 8.;
		else if (n == 1 || n == nTra - 2) a = 7. / 6.;
		else if (n == 2 || n == nTra - 3) a =  23. / 24.;
		else a = 1.;
		integral += a * tra[n].d * tra[n].n; //--dimensionless(3D); --nm(2D)
	}
	integral *= dE;

	//check
	dnMax = 0.;
	DO_TRA dnMax = Max (dnMax, tra[n].d * tra[n].n);
	dnLeft = (tra[0].d * tra[0].n) / dnMax;
	dnRight = (tra[nTra-1].d * tra[nTra-1].n) / dnMax;
	if (dnLeft > 0.01) {
		printf("error(emission.c): F = %.2e V/nm, T = %.2f K, N*D: left percent = %.2f%%\n", \
		       F_V_nm, T_K, dnLeft * 100.);
		PrintPoten (F_V_nm, GAP_nm);
		PrintTra (F_V_nm, GAP_nm);
		ErrExit (ERR_TRANSMITION_DN_INTEGRATION);
	}
	if (dnRight > 0.01) {
		printf("error(emission.c): F = %.2e V/nm, T = %.2f K, N*D: right percent = %.2f%%\n", \
		       F_V_nm, T_K, dnRight * 100.);
		PrintPoten (F_V_nm, GAP_nm);
		PrintTra (F_V_nm, GAP_nm);
		ErrExit (ERR_TRANSMITION_DN_INTEGRATION);
	}

//	g4 = (eleMass * kB * T_K) / (2. * Sqr(M_PI) * Cube(planck_)) * eleChar * 1.e-18; //--A/nm2J
//	JEMI_A_nm2 = eleChar * VG_V * g4 * integral; //--A/nm2
	JEMI_A_nm2 = Zs_A_eV2nm2 * (kB * T_K / eleChar) * (integral * VG_V); //--A/nm2(3D); --A/nm(2D)

	return (JEMI_A_nm2);
}

real CalPN (real F_V_nm, real T_K, real dE, real VG_V, real GAP_nm)
{
	int n, i;
	real PN_W_nm2; //--W/nm2
	real kT_eV, kT, integral;

	kT_eV = kB * T_K / eleChar; //--eV
	kT = kT_eV / VG_V; //--dimensionless

#if NDIM==3 //3D
	DO_TRA tra[n].integralD = 0.;
	DO_TRA {
		for (i = 0; i < n; i ++) {
			tra[n].integralD += tra[i].d * dE;
		}
		tra[n].M = tra[n].E / (1. + exp(tra[n].E / kT)); //--dimensionless
		tra[n].integrandPN = tra[n].integralD * tra[n].M;
	}
	integral = 0.;
	DO_TRA {
		integral += tra[n].integrandPN * dE; //--dimensionless
	}
	PN_W_nm2 = Zs_A_eV2nm2 * integral * Cube(VG_V); //--W/nm2(3D)

#elif NDIM==2 //2D
	DO_TRA tra[n].integralD = 0.;
	DO_TRA {
		for (i = 0; i < n; i ++) {
			tra[n].integralD += tra[i].d * dE;
		}
		if (tra[n].E > 0) tra[n].M = sqrt(fabs(tra[n].E)) / (1. + exp(tra[n].E / kT)); //--dimensionless
		else tra[n].M = - sqrt(fabs(tra[n].E)) / (1. + exp(tra[n].E / kT)); //--dimensionless
		tra[n].integrandPN = tra[n].integralD * tra[n].M;
	}
	integral = 0.;
	DO_TRA {
		integral += tra[n].integrandPN * dE; //--dimensionless
	}
	PN_W_nm2 = Zs_A_eV3_2nm * integral * pow(VG_V, 5./2.); //--W/nm(2D)
#endif

	return (PN_W_nm2);
}

real CalJFN (real F_V_nm, real phiWF_eV) //Fowler-Nordheim law (Murphy-Good version) --V/nm; A/nm2
{
	int Ntheta, n, i;
	real AFN, BFN, ty, vy, y, E0, c, JFN, k, Kk, Ek, theta, dtheta;
	real dv[3]={0}, dy[3]={0};

	//get emission parameters
	SetParamsEmi ();

	E0 = F_V_nm * 1.e9; //--V/m
	AFN = 1.5414e-6; //--A/eV
	BFN = 6.8309e9; //--eV-1/2 m-1
	c = 3.7947e-5; //--(eV m)1/2
	y = c * sqrt(E0) / phiWF_eV; //--dimensionless

	if (y >= 0 && y <= 1) { // that is to say : F < 14V/nm
		vy = 1. - Sqr(y) + (Sqr(y) * log(y)) / 3.;
		ty = 1. + Sqr(y) / 9. - Sqr(y) * log(y) / 9.;
	} else {

		dy[0] = y - 0.01;
		dy[1] = y;
		dy[2] = y + 0.01;
		for (i = 0; i < 3; i ++) {
			k = sqrt((dy[i] - 1.) / (2. * dy[i]));
			Ntheta = 1000;
			dtheta = (M_PI / 2.) / Ntheta;
			Kk = 0.;
			Ek = 0.;
			for (n = 0; n < Ntheta; n ++) {
				theta = n * dtheta;
				Kk += pow((1. - Sqr(k) * Sqr(sin(theta))), -0.5) * dtheta;
				Ek += pow((1. - Sqr(k) * Sqr(sin(theta))), 0.5) * dtheta;
			}
			dv[i] = -sqrt(dy[i] / 2.) * (-2. * Ek + (dy[i] + 1.) * Kk);
		}
		vy = dv[1];
		ty = vy - (2. / 3.) * y * (dv[2] - dv[0]) / (dy[2] - dy[0]);
	}
//	vy = 1.;
//	ty = 1.;

	JFN = (AFN * Sqr(E0)) / (phiWF_eV * Sqr(ty)) * exp(- BFN * vy * pow(phiWF_eV, 1.5) / E0); //--A/m2
	JFN *= 1.e-18; //--A/nm2

	return (JFN);
}

real CalJRLD (real F_V_nm, real T_K, real phiWF_eV)
{
	real ARLD, JRLD, kT_eV, E0, c, y;

	//get emission parameters
	SetParamsEmi ();

	ARLD = 1.2017e6; //--A m-2 K-2
	c = 3.7947e-5; //--(eV m)1/2
	E0 = F_V_nm * 1.e9; //--V/m
	y = c * sqrt(E0) / phiWF_eV; //--dimensionless
	kT_eV = kB * T_K / eleChar; //--eV

	JRLD = ARLD * Sqr(T_K) * exp(- phiWF_eV * (1. - y) / kT_eV); //--A/m2
	JRLD *= 1.e-18; //--A/nm2

	return (JRLD);
}

real CalJCL (real VG_V, real GAP_nm) //--V, nm; A/nm2
{
	real GAP_m, JCL;

	GAP_m = GAP_nm * 1.e-9; //--m
	JCL = ((4. * epsilon0) / 9.) * sqrt((2. * eleChar) / eleMass) * (pow(VG_V, 1.5) / Sqr(GAP_m)); //--A/m2
	JCL *= 1.e-18; //--A/nm2

	return (JCL);
}

real GreenFunctionD20 (real q, real kappa0, real kappa2, real x, real L) //--A-1, A-1, A, A
{
	real gamma1s, gamma2s, dDvac0, D20, a, term1, term2, temp;
	if (fabs(PHIWF_eV - PHIWF2_eV) < 1.e-100 && fabs(EF_eV - EF2_eV) < 1.e-100) { //anode and cathod are the same metal
/*
		gamma1s = sqrt(Sqr(q) + Sqr(kappa0)) * (sqrt(Sqr(q) + Sqr(kappa0))
			  * (sinh((L - x) * q) * cosh((L - x) * q)
			     + sinh(x * q) * cosh(x * q))
			  + q * (Sqr(cosh((L - x) * q)) + Sqr(cosh(x * q)))); //--A-2
		gamma2s = q * sinh(L * q) * ((2. * Sqr(q) + Sqr(kappa0)) * sinh(L * q)
			  + 2. * q * sqrt(Sqr(q) + Sqr(kappa0)) * cosh(L * q)); //--A-3
		dDvac0 = - 1. / (2. * q) * (cosh((L - 2. * x) * q) + cosh(L * q)) / sinh(L * q); //--A
		D20 = gamma1s / gamma2s + dDvac0; //--A
		if (isfinite(gamma1s) == 0 || isfinite(gamma2s) == 0) {
			printf ("\nerror: green function calculation for image potential in TFA\n");
			exit (1);
		}
*/
		//in case gamma1s or gamma2s would be out of the maximum of double, we use the following method
		a = (2. * Sqr(q) + Sqr(kappa0)) * sinh(L * q)
			  + 2. * q * sqrt(Sqr(q) + Sqr(kappa0)) * cosh(L * q);
		term1 = sqrt(Sqr(q) + Sqr(kappa0)) * (sqrt(Sqr(q) + Sqr(kappa0))
			  * (sinh((L - x) * q) / a * cosh((L - x) * q)
			     + sinh(x * q) / a * cosh(x * q))
			  + q * (cosh((L - x) * q) / a * cosh((L - x) * q)
				 + cosh(x * q) / a * cosh(x * q)));
		term2 = term1 / (q * sinh(L * q));
		dDvac0 = - 1. / (2. * q) * (cosh((L - 2. * x) * q) / sinh(L * q) + cosh(L * q) / sinh(L * q)); //--A
		D20 = term2 + dDvac0;
	} else { //anode and cathod use different metals
		a = (Sqr(q) + sqrt(Sqr(q) + Sqr(kappa0)) * sqrt(Sqr(q) + Sqr(kappa2))) * sinh(L * q)
			  + q * (sqrt(Sqr(q) + Sqr(kappa0)) + sqrt(Sqr(q) + Sqr(kappa2))) * cosh(L * q);
		term1 = sqrt(Sqr(q) + Sqr(kappa0)) * sqrt(Sqr(q) + Sqr(kappa2))
			  * (sinh((L - x) * q) / a * cosh((L - x) * q)
			     + sinh(x * q) / a * cosh(x * q))
			  + q * sqrt(Sqr(q) + Sqr(kappa0)) * cosh((L - x) * q) / a * cosh((L - x) * q)
			  + q * sqrt(Sqr(q) + Sqr(kappa2)) * cosh(x * q) / a * cosh(x * q);
		term2 = term1 / (q * sinh(L * q));
		dDvac0 = - 1. / (2. * q) * (cosh((L - 2. * x) * q) / sinh(L * q) + cosh(L * q) / sinh(L * q)); //--A
		D20 = term2 + dDvac0;
	}

	//check
	if (isfinite(D20) == 0 && fabs(x) > 1.e-100 && fabs(L - x) > 1.e-100) {
		printf ("\nerror (emission.c - GreenFunctionD20()): green function calculation for image potential in TFA\n");
		printf ("x = %.4f A, L = %.4f A, q = %.4f A-1, kappa0 = %.4f A-1, a = %.4e, term1 = %.4e, term2 = %.4e, dDvac0 = %.4e, D20 = %.4e\n", \
			 x, L, q, kappa0, a, term1, term2, dDvac0, D20);
		exit (1);
	}

	return (D20);
}

real ImagePotentialTFA (real X_A, real L_A) //--A, A; --eV
{
	int n, Nq;
	real chi, phiWF, EF, kappa0, L, x, q, dq, D20, V20, term, term0, term1, term2, qMin, qMax, integral;
	real chi2, phiWF2, EF2, kappa2;

	phiWF = PHIWF_eV; //--eV
	EF = EF_eV; //--eV
	chi = phiWF + EF; //--eV
	chi *= eleChar; //--J
	kappa0 = 8. * M_PI * epsilon0 * chi / Sqr(eleChar); //--m-1
	kappa0 *= 1.e-10; //--A-1

	phiWF2 = PHIWF2_eV; //--eV
	EF2 = EF2_eV; //--eV
	chi2 = phiWF2 + EF2; //--eV
	chi2 *= eleChar; //--J
	kappa2 = 8. * M_PI * epsilon0 * chi2 / Sqr(eleChar); //--m-1
	kappa2 *= 1.e-10; //--A-1

	L = L_A; //--A
	x = X_A; //--A

	//find the range of q
	q = 0.00001; //--A-1
	dq = 0.01; //--A-1
	while (1) 
	{
		D20 = GreenFunctionD20 (q, kappa0, kappa2, x, L); //--A-1, A-1, A, A
		term = q * dq * (D20 + 1. / (2. * q)); //--A-1
//		printf ("q = %.2f term = %.4e\n", q, term);
		if (q < dq) term0 = term;
		if (term / term0 < 0.001) {
			qMax = q;
			break;
		}
		q += dq;
	}
	qMin = 1.e-8;

	//integration
	Nq = 1000;
	dq = (qMax - qMin) / (Nq - 1.);
	q = qMin;
	integral = 0.;
	while (1)
	{
		if (fabs(q - qMax) < 1.e-8) break;

		D20 = GreenFunctionD20 (q, kappa0, kappa2, x, L); //--A-1, A-1, A, A
		term1 = q * (D20 + 1. / (2. * q)); //--A-1
		D20 = GreenFunctionD20 (q+dq, kappa0, kappa2, x, L);
		term2 = (q+dq) * (D20 + 1. / (2. * (q + dq)));
		term = (term1 + term2) / 2.;
		integral += term * dq; //--A-1
		q += dq;
	}

	integral *= 1.e10; //--m-1
	V20 = - Sqr(eleChar) / (4. * M_PI * epsilon0) * integral; //--J

	return (V20 / eleChar); //--eV
}

//image-charge potential k / (x + x0)
real ImagePotentialx0 (real X_A) //--A; eV
{
	real chi, kappa, EF, rTF, x0, x1, x, V1;

	chi = PHIWF_eV + EF_eV; //--eV
	chi *= eleChar; //--J
	kappa = 8. * M_PI * epsilon0 * chi / Sqr(eleChar); //--m-1
	EF = EF_eV * eleChar; //--J
	rTF = 1. / kappa; //--m
	x0 = 0.75 * rTF; //--m
	x1 = rTF; //--m
	x = X_A; //--A
	x *= 1.e-10; //--m
	if (x < 0) {
		V1 = - Sqr(eleChar) * kappa / (8. * M_PI * epsilon0) + Sqr(eleChar) / (16. * M_PI * epsilon0 * (fabs(x) + 2. * x0)) * exp(-2. * kappa * fabs(x)); //--J
	} else {
		V1 = - Sqr(eleChar) / (16. * M_PI * epsilon0 * (x + x0)); //--J
	}

	return (V1 / eleChar); //--eV
}

void PrintPoten (real F_V_nm, real D_nm)
{
	int n;
	double V;

	V = F_V_nm * D_nm; //--V
	DO_EMI {
		fprintf (potential_file, "%e %e %e %e %e %e %e %e\n", \
			 F_V_nm, D_nm, emi[n].x * D_nm, emi[n].barrier * V, emi[n].phia * V, emi[n].phiic * V, emi[n].phixc * V, emi[n].phisc * V); //--F/nm, nm, nm, eV
	}
}

void PrintPotenTotal (real F_V_nm, real D_nm)
{
	int n;
	double V;

	V = F_V_nm * D_nm; //--V
	DO_EMI {
		fprintf (potentialTotal_file, "%e %e %e %e %e %e %e %e\n", \
			 F_V_nm, D_nm, emi[n].x * D_nm, emi[n].barrier * V, emi[n].phia * V, emi[n].phiic * V, emi[n].phixc * V, emi[n].phisc * V); //--F/nm, nm, dimensionless
	}
}


void PrintTra (real F_V_nm, real D_nm)
{
	int n;

	DO_TRA {
		fprintf (transmission_file, "%e %e %e %e %e %e %e %e %e %e\n", \
			 F_V_nm, D_nm, tra[n].E, tra[n].g, tra[n].d, tra[n].n, tra[n].d * tra[n].n, \
			 tra[n].integralD, tra[n].M, tra[n].integrandPN); //--dimensionless
	}
}

void AllocMemEmi ()
{
	AllocMem (emi, nEmi, Emission);
	AllocMem (tra, nTra, Transmission);
}

void ReAllocMemEmi ()
{
	ReAllocMem (emi, nEmi, Emission);
	ReAllocMem (tra, nTra, Transmission);
}

void FreeEmi ()
{
	free (emi);
	free (tra);
}
