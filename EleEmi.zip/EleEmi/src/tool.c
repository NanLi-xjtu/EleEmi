#include "tool.h"

#define IADD	453806245
#define IMUL	314159269
#define MASK	2147483647
#define SCALE	0.4656612873e-9

int randSeedP = 17;
char *errorMsg[] = {"", "bond snapped", "read checkpoint data",
	"write checkpoint data", "copy buffer full", "empty event pool",
	"message buffer full", "outside region", "read snap data",
	"write snap data", "subdivision unfinished", "too many cells",
	"too many copied mols", "too many layers", "too many levels",
	"too many mols", "too many moved mols", "too many neighbors",
	"too many replicas", "surface atoms count", "gridSize is too small",
	"heatCell atoms count", "potential barrier integration",
	"transmission D*N integration", "EAM potential file Input"};

real RandR ()
{
	randSeedP = (randSeedP * IMUL + IADD) & MASK;
	return (randSeedP * SCALE);
}

void InitRand (int randSeedI)
{
	struct timeval tv;

	if(randSeedI != 0) randSeedP = randSeedI;
	else{
		gettimeofday (&tv, 0);
		randSeedP = tv.tv_usec;
	}
}

void VRand (VecR *p)
{
	real s;

	s = 2. * M_PI * RandR ();
	p->x = cos (s);
	p->y = sin (s);
}

void ErrExit (int code)
{
	printf ("Error: %s\n", errorMsg[code]);
	exit (0);
}

real Integral1D (real xa, real xb, int nMax)
{
	int n;
	real x, fx, fxAvg, I, xRange;

	xRange = xb - xa;
	I = 0;
	for (n = 0;n < nMax; n ++) {
		InitRand (n);
		x = RandR () * xRange + xa;

/*********************************Function*********************************/
		fx = 1. / (1. + exp(x));

		fxAvg += fx;
	}
	fxAvg /= nMax;
	I = fxAvg * xRange;

	return (I);
}

real Integral2D (real xa, real xb, real ya, real yb, int nMax)
{
	int n;
	real x, y, fxy, fxyAvg, I, xRange, yRange;

	xRange = xb - xa;
	yRange = yb - ya;
	I = 0;
	for (n = 0;n < nMax; n ++) {
		InitRand (n);
		x = RandR () * xRange + xa;
		y = RandR () * yRange + ya;

/*********************************Function*********************************/
		fxy = Sqr(x) * Sqr(y);

		fxyAvg += fxy;
	}
	fxyAvg /= nMax;
	I = fxyAvg * xRange * yRange;

	return (I);
}
