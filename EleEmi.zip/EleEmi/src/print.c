#include "print.h"

FILE *namelist_file;
FILE *summary_file;
FILE *potential_file; //emission - Potential barrier
FILE *potentialTotal_file;
FILE *potentialAvg_file;
FILE *transmission_file; //emission - G(E) D(E) 
FILE *Jemission_file; //emission current
FILE *NottinghamHeat_file; //Nottingham heat PN
FILE *QCL_file;
FILE *qe_file;
FILE *Jqe_file;

NameList nameList[] = {
	NameR (PHIWF_eV),
	NameR (EF_eV),
	NameR (PHIWF2_eV),
	NameR (EF2_eV),
	NameI (anode),
	NameI (optionTFA),
	NameI (optionPhixc),
	NameI (Ncore),
	NameI (Nqe),
	NameR (qe_omega),
	NameI (func_X_id),
	NameI (func_C_id),
	NameI (printQE),
	NameI (qeflag),
};

void PrintOpen()
{
	if ((namelist_file = fopen ("./out/namelist.dat", "w")) == NULL){
		printf ("\nopen summary file error");
		getchar ();
		exit (1);
	}
	if ((potential_file = fopen ("out/barrierPotential.dat", "w")) == NULL){
		printf ("\nopen barrierPotential file error");
		getchar ();
		exit (1);
	}
	fprintf (potential_file, "F(V/nm) D(nm) x(nm) U(eV) phia(eV) phiic(eV) phixc(eV) phisc(eV)\n");
	if ((potentialTotal_file = fopen ("out/barrierPotentialTotal.dat", "w")) == NULL){
		printf ("\nopen barrierPotentialTotal file error");
		getchar ();
		exit (1);
	}
	fprintf (potentialTotal_file, "F(V/nm) D(nm) x(nm) U(eV) phia(eV) phiic(eV) phixc(eV) phisc(eV)\n");
	if ((transmission_file = fopen ("out/transmission.dat", "w")) == NULL){
		printf ("\nopen transmission file error");
		getchar ();
		exit (1);
	}
	fprintf (transmission_file, "F(V/nm) D(nm) E G D N D*N integralD M integrandPN\n");
	if ((Jemission_file = fopen ("out/Jemission.dat", "w")) == NULL){
		printf ("\nopen Jemission file error");
		getchar ();
		exit (1);
	}
	if ((NottinghamHeat_file = fopen ("out/NottinghamHeat.dat", "w")) == NULL){
		printf ("\nopen Nottingham Heat file error");
		getchar ();
		exit (1);
	}
#if NDIM==3
	fprintf (Jemission_file, "F(V/nm) D(nm) T(K) J(A/nm2)\n");
	fprintf (NottinghamHeat_file, "F(V/nm) D(nm) PN(W/nm2)\n");
#elif NDIM==2
	fprintf (Jemission_file, "F(V/nm) D(nm) T(K) J(A/nm)\n");
	fprintf (NottinghamHeat_file, "F(V/nm) D(nm) PN(W/nm)\n");
#endif
	
	if ((QCL_file = fopen ("out/QCL.dat", "w")) == NULL){
		printf ("\nopen QCL file error");
		getchar ();
		exit (1);
	}
	if ((qe_file = fopen ("out/quantum emission.dat", "w")) == NULL){
		printf ("\nopen quantum emission file error");
		getchar ();
		exit (1);
	}
	fprintf (qe_file, "F(V/nm) D(nm) x q phi phixc phix phic rs q2 theta\n");
	if ((Jqe_file = fopen ("out/Jqe.dat", "w")) == NULL){
		printf ("\nopen Jqe file error");
		getchar ();
		exit (1);
	}
	fprintf (Jqe_file, "F(V/nm) D(nm) u q phi phixc phix phic approximate\n");
}

void PrintClose()
{
	fclose (namelist_file);
	fclose (potential_file);
	fclose (potentialTotal_file);
	fclose (transmission_file);
	fclose (Jemission_file);
	fclose (QCL_file);
	fclose (qe_file);
	fclose (Jqe_file);

}
int GetNameList (int argc, char **argv)
{
	int id, j, k, match, ok;
	char buff[80], *token;
	FILE *fp;

	sprintf (buff, "./in/%s.in", argv[0]);
	if ((fp = fopen (buff, "r")) == 0) return (0);
	for (k = 0; k < sizeof (nameList) / sizeof (NameList); k ++)
		nameList[k].vStatus = 0;
	ok = 1;
	while (1){
		fgets (buff, 80, fp);
		if (feof (fp)) break;
		token = strtok (buff, "\t\n");
		if (! token) break;
		match = 0;
		for (k = 0; k < sizeof (nameList) / sizeof (NameList); k++){
			if (strcmp (token, nameList[k].vName) == 0){
				match = 1;
				if (nameList[k].vStatus == 0){
					nameList[k].vStatus = 1;
					for (j = 0; j < nameList[k].vLen; j++){
						token = strtok (NULL, ", \t\n");
						if (token){
							switch (nameList[k].vType){
								case N_I:
									*NP_I = atol (token);
									break;
								case N_R:
									*NP_R = atof (token);
									break;
							}
						} else{
							nameList[k].vStatus = 2;
							ok = 0;
						}
					}
					token = strtok (NULL, ", \t\n");
					if (token){
						nameList[k].vStatus = 3;
						ok = 0;
					}
					break;
				}else{
					nameList[k].vStatus = 4;
					ok = 0;
				}
			}
		}
		if (! match) ok = 0;
	}
	fclose (fp);
	for (k = 0; k < sizeof (nameList) / sizeof (NameList); k ++){
		if (nameList[k].vStatus != 1) ok = 0;
	}
	return (ok);
}

void PrintNameList (FILE *fp)
{
	int j, k;

	fprintf (fp, "NameList -- data\n");
	for (k = 0; k < sizeof (nameList) / sizeof (NameList); k ++){
		fprintf (fp, "%s\t", nameList[k].vName);
		if (strlen (nameList[k].vName) < 8) fprintf (fp, "\t");
		if (nameList[k].vStatus > 0){
			for (j = 0; j < nameList[k].vLen; j ++){
				switch (nameList[k].vType){
					case N_I:
						fprintf (fp, "%d ", *NP_I);
						break;
					case N_R:
						fprintf (fp, "%#g ", *NP_R);
						break;
				}
			}
		}
		switch (nameList[k].vStatus){
			case 0:
				fprintf (fp, "** no data");
				break;
			case 1:
				break;
			case 2:
				fprintf (fp, "** missing data");
				break;
			case 3:
				fprintf (fp, "** extra data");
				break;
			case 4:
				fprintf (fp, "** multiply defined");
				break;
		}
		fprintf (fp, "\n");
	}
	fprintf (fp, "----\n");
}

FILE *ReadFile (char filename[128])
{
	FILE *input;
	
	if ((input = fopen (filename, "r")) == NULL) {
		printf ("%s does not exsit\n", filename);
		exit (1);
	}
	
	return (input);
}

FILE *WriteFile (char filename[128])
{
	FILE *output;
	
	if ((output = fopen (filename, "w")) == NULL) {
		printf ("%s does not exsit\n", filename);
		exit (1);
	}
	
	return (output);
}
