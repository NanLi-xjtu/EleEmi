#ifndef NR_H
#define NR_H

#include "main.h"

void Spline(double x[], double y[], int n, double yp1, double ypn, double y2[]);
void Splint(double xa[], double ya[], double y2a[], int n, double x, double *y);
void polint(double xa[], double ya[], int n, double x, double *y, double *dy);

#endif
