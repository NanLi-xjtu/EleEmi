#define  XC_LDA_K_GDS08_WORKER          100001  /*Combined analytical theory with Monte Carlo sampling                  */
