#ifndef EMIINIT_H
#define EMIINIT_H

#include "main.h"

void EmissionInit ();
void SetParamsEmi ();
void SetParamsQE ();
void SetupJobQE ();
void EndJobQE ();

#endif
