#ifndef QE_H
#define QE_H

#include "main.h"

#define DO_QE for(n = 0; n < Nqe; n ++)

typedef struct {
	real x;
	real q, phi, phixc, phix, phic; //real functions of the wave amplitude, space charge potential, \
					  exchange-correlation potential, exchange potential, correlation potential
	real rs; //local Seitz radius
	real q2, theta; //normalized electron density, real functions of the wave phase
} QE;

typedef struct {
	real *rho; //density
	real *x;
	real *sigma, *deltaRho; //gradients of the density
	real *exc, *ex, *ec; //energy per partical
	real *Vxc, *Vx, *Vc; //potential
	real *VxRho, *VcRho;
	real *VxSigma, *VcSigma;
	real *gVxSigma, *gVcSigma;
	real *lapl; //the laplacian of the density
	real *tau; //the kinetic energy density
	real *VxLapl, *VcLapl;
	real *VxTau, *VcTau;
	real *rs;
} DFT;

extern QE *qe, *qclOld;
extern DFT dft;
extern xc_func_type func_X, func_C;
extern int Nqe;
extern int Ncore; //the number of threads
extern int func_X_id, func_C_id;
extern int optionQE;
extern int optionPhixc; //include phixc(1); not include phixc(0);
extern int approximateQE; //the result is real(0) or approximate(1)
extern real dqe, qe_omega;
extern real phixcAvgQE, phixAvgQE, phicAvgQE, phiAvgQE, qAvg, nAvg, nAvg__m3;
extern real uLastPoint;
extern int printQE;
extern int qeflag;

real QuantumEmission (real Vg, real D, real T, int optionPrint, real omega, real CONV); //--V, nm, K;
void QCLInit (real lambda, int N);
void BoundaryCondition_Koh (real ux);
void DFTCalculation (QE *qe, real lambda, real phig, real Vg_V, real D_nm);
void SingleQCLFunction (int i, real ux, real lambdax, real phigx);
int CalQCLFunction (real ux, real lambdax, real phigx, real Vg_V, real D_nm, real CONV);
void SingleQCL_Koh (real lambdax, real phigx, real Vg_V, real D_nm, real CONV);
void CalJQCL_Koh (real CONV);
void PrintQE (real F_V_nm, real D_nm);
void FreeQE ();
FILE *ReadFile (char filename[128]);
FILE *WriteFile (char filename[128]);

#endif
