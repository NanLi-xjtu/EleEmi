#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <omp.h>
#include <sys/stat.h>
#include <xc.h>

#include "define.h"
#include "nrutil.h"
#include "nr.h"
#include "tool.h"
#include "print.h"
#include "emission.h"
#include "emiInit.h"
#include "qe.h"

void SingleStep ();
void CheckParallel ();
void LibxcInit (xc_func_type *func, int func_id);
void FreeMem ();

#endif
