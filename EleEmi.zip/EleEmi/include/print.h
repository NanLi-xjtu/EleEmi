#ifndef PRINT_H
#define PRINT_H

#include "main.h"

typedef enum {N_I, N_R} VType;
typedef struct {
	char *vName;
	void *vPtr;
	VType vType;
	int vLen, vStatus;
} NameList;

#define NameI(x) {#x, &x, N_I, sizeof (x) / sizeof (int)}
#define NameR(x) {#x, &x, N_R, sizeof (x) / sizeof (real)}
#define NP_I ((int *) (nameList[k].vPtr) + j)
#define NP_R ((real *) (nameList[k].vPtr) + j)

extern FILE *namelist_file;
extern FILE *summary_file;
extern FILE *md_file;
extern FILE *veldist_file;
extern FILE *rdf_file;
extern FILE *ligancy_file;
extern FILE *surfaceFitting_file;
extern FILE *electric_file;
extern FILE *surfaceAtoms_file;
extern FILE *surfaceGrids_file;
extern FILE *heatCell_file;
extern FILE *potential_file; //emission - Potential barrier
extern FILE *potentialTotal_file;
extern FILE *potentialAvg_file;
extern FILE *transmission_file; //emission - G(E) D(E) 
extern FILE *Jemission_file; //emission current
extern FILE *NottinghamHeat_file; //Nottingham heat PN
extern FILE *QCL_file;
extern FILE *qe_file;
extern FILE *Jqe_file;
extern FILE *test_file;

int GetNameList (int argc, char **argv);
void PrintNameList (FILE *fp);
void PrintOpen();
void PrintClose();

#endif
