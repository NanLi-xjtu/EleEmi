#ifndef EMISSION_H
#define EMISSION_H

#include "main.h"

#define NPOINTS 1000

typedef struct {
	VecR r, field;
	real CHARGE_C_m2;
	int n; // -> mol[n]
	real temp; //dimensionless, TUnit
	real J_A_nm2; //--A/nm2
	real PN_W_nm2; //--W/nm2
	int type; //1 : positive electrode. 0 : negative electrode
} SurfaceAtoms;

typedef struct {
	int i, j;
	VecR field;
	real temp; //dimensionless, TUnit
	real J_A_nm2; //--A/nm2
	real PN_W_nm2;
	int type; //1 : positive electrode. 0 : negative electrode
} SurfaceGrids;

typedef struct {
	real x;
	real phia, phiic, phixc, phisc, barrier;
} Emission;

typedef struct {
	real E;
	real g, d, n;
	real integralD, M, integrandPN;
} Transmission;

#define DO_SAT for(n = 0; n < satCount; n ++)
#define DO_SGR for(n = 0; n < sgrCount; n ++)
#define DO_EMI for(n = 0; n < nEmi; n++)
#define DO_TRA for(n = 0; n < nTra; n++)

extern SurfaceAtoms *sat;
extern int satCount;
extern SurfaceGrids *sgr;
extern int sgrCount;

extern Emission *emi;
extern Transmission *tra;
extern real PHIWF_eV, phiWF, EF_eV; //cathod
extern real PHIWF2_eV, EF2_eV; //anode
extern real JCL_A_nm2, JEMI_A_nm2, JFN_A_nm2, JQCL_JCL;
extern int nEmi, nTra;
extern real xRangeMax, xRangeMin; //dimensionless
extern real eRangeMax, eRangeMin; //dimensionless
extern real Nottingham_W_nm2; //--W/nm2
extern int anode; //metal-vacuum-metal(1) or metal-vacuum(0)
extern int optionTFA; //image potential for TFA
extern int optionMetal; //the same metal (1) or different metals (2) for anode and cathod
extern real UAvg, phiWFAvg, phiaAvg, phiicAvg, phiscAvg, phixcAvg;
extern real UAvg_eV, phiWFAvg_eV, phiaAvg_eV, phiicAvg_eV, phiscAvg_eV, phixcAvg_eV;
//constant
extern real Q_Jm, Q_eVnm;
extern real Zs_A_eV2nm2, Zs_A_eV3_2nm;
extern real g1__eV1_2nm, g2__eV1_2nm; //--(eV)-1/2(nm)-1

extern int stepEmiTest;

void SingleStepEmi ();
void CalSurfaceCharge ();
void CalSurfaceAtomsEmission ();
void CalSurfaceGridsEmission ();
real ObtainEmissionCurrent (real GAP_nm, real F_V_nm, real T_K, real R_nm, real gamma, int optionPrint);
void CalBarPoten (real F_V_nm, real VG_V, real GAP_nm, real R_nm, real gamma, real dx);
void CalAppPoten (real F_V_nm, real VG_V, real GAP_nm, real R_nm, real gamma);
void CalImaPoten (real VG_V, real GAP_nm, real R_nm);
real ImagePotentialx0 (real X_A); //--A; eV
void CalXCPoten (real F_V_nm, real GAP_nm);
void CalSCPoten (real F_V_nm, real GAP_nm);
void ObtainERange (real F_V_nm, real T_K, real VG_V, real GAP_nm, real dx);
void ObtainXRange ();
real FunctionG (real E, real F_V_nm, real VG_V, real GAP_nm, real GUm_, real dx);
real FunctionN (real E, real T_K, real VG_V); //E--dimensionless; T_K--K
real CalJemi (real F_V_nm, real T_K, real dE, real dx, real VG_V, real GAP_nm);
real CalPN (real F_V_nm, real T_K, real dE, real VG_V, real GAP_nm); //Nottingham heat
real CalJFN (real F_V_nm, real phiWF_eV); //Fowler-Nordheim law (Murphy-Good version) --V/nm; A/nm2
real CalJRLD (real F_V_nm, real T_K, real phiWF_eV); //Richardson-Laue-Dushman law
real CalJCL (real VG_V, real GAP_nm); //CL Laws
real GreenFunctionD20 (real q, real kappa0, real kappa2, real x, real L); //--A-1, A-1, A, A
real ImagePotentialTFA (real X_A, real L_A); //--A, A; --eV
void PrintPoten (real F_V_nm, real D_nm);
void PrintPotenTotal (real F_V_nm, real D_nm);
void PrintTra (real F_V_nm, real D_nm);
void PrintSurfaceAtoms ();
void PrintSurfaceGrids ();
void AllocMemEmi ();
void ReAllocMemEmi ();
void FreeSurfaceAtoms ();
void FreeSurfaceGrids ();
void FreeEmi ();

void EmiTest ();

#endif
